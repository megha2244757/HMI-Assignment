import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import SpotifyMusicPlayer from "@/components/SpotifyMusicPlayer";
import SpotifyNowPlaying from "@/components/SpotifyNowPlaying";
import WeatherCurrent from "@/components/WeatherCurrent";
import WeatherForecast from "@/components/WeatherForecast";
import FeedbackForm from "@/components/FeedbackForm";
import FeedbackList from "@/components/FeedbackList";
import { Music2, CloudSun } from "lucide-react";
import albumArt1 from '@assets/generated_images/Album_cover_gradient_art_ce162ed5.png';
import albumArt2 from '@assets/generated_images/Electronic_album_cover_art_ec1eaee8.png';
import type { WeatherData } from "@shared/schema";

export default function Home() {
  const [feedbackItems, setFeedbackItems] = useState([
    {
      id: "1",
      widgetName: "Spotify Music Player Controls",
      rating: 5,
      comment: "The controls are very intuitive and responsive. Love the green accent color that matches Spotify's branding. The play/pause animation is smooth and the progress bar is easy to understand.",
      testerName: "Sarah Johnson",
      createdAt: new Date(Date.now() - 1000 * 60 * 30),
    },
    {
      id: "2",
      widgetName: "Apple Weather Current",
      rating: 4,
      comment: "Clean iOS-style design with clear temperature display. The weather icon is simple and recognizable. Would be nice to have more detailed information like humidity or wind speed.",
      testerName: "Michael Chen",
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 2),
    },
    {
      id: "3",
      widgetName: "Spotify Now Playing Summary",
      rating: 5,
      comment: "Perfect at-a-glance widget! The album art is prominent and the NOW PLAYING label helps distinguish it from the full player. Very minimal and clean.",
      testerName: "Emily Rodriguez",
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 5),
    },
    {
      id: "4",
      widgetName: "Apple Weather Forecast",
      rating: 4,
      comment: "The 3-day forecast layout is well-organized and easy to scan. The icons are clear and the temperature values are prominent. Great use of iOS design principles.",
      testerName: "David Park",
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 8),
    },
  ]);

  const { data: weatherData, isLoading: weatherLoading } = useQuery<WeatherData>({
    queryKey: ['/api/weather/Hubli'],
  });

  const handleFeedbackSubmit = (feedback: {
    widgetName: string;
    rating: number;
    comment: string;
    testerName: string;
  }) => {
    const newFeedback = {
      id: Date.now().toString(),
      ...feedback,
      createdAt: new Date(),
    };
    setFeedbackItems([newFeedback, ...feedbackItems]);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-md mx-auto px-4 py-8 space-y-8">
        <header className="text-center space-y-2">
          <h1 className="text-3xl font-bold">HMI Widget Assignment</h1>
          <p className="text-muted-foreground">
            Mobile App Widgets: Spotify & Apple Weather
          </p>
        </header>

        <section className="space-y-6">
          <div className="flex items-center gap-2">
            <Music2 className="w-6 h-6 text-spotify-green" />
            <h2 className="text-2xl font-semibold">Spotify Widgets</h2>
            <span className="text-xs text-muted-foreground">(Android Material UI)</span>
          </div>
          
          <div className="space-y-4">
            <SpotifyMusicPlayer
              albumArt={albumArt1}
              songTitle="Midnight Vibes"
              artist="The Electric Dreams"
              audioUrl="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
            />
            
            <SpotifyNowPlaying
              albumArt={albumArt2}
              songTitle="Neon Lights"
              artist="Synthwave Runner"
              isPlaying={true}
            />
          </div>
        </section>

        <section className="space-y-6">
          <div className="flex items-center gap-2">
            <CloudSun className="w-6 h-6 text-ios-blue" />
            <h2 className="text-2xl font-semibold">Apple Weather Widgets</h2>
            <span className="text-xs text-muted-foreground">(iOS Flat Design)</span>
          </div>
          
          {weatherLoading ? (
            <div className="text-center py-8 text-muted-foreground">
              Loading weather data for Hubli...
            </div>
          ) : weatherData ? (
            <div className="space-y-4">
              <WeatherCurrent
                temperature={weatherData.temperature}
                condition={weatherData.condition}
                location={weatherData.location}
                highTemp={weatherData.highTemp}
                lowTemp={weatherData.lowTemp}
              />
              
              <WeatherForecast forecast={weatherData.forecast} />
            </div>
          ) : (
            <div className="space-y-4">
              <WeatherCurrent
                temperature={28}
                condition="sunny"
                location="Hubli"
                highTemp={32}
                lowTemp={22}
              />
              
              <WeatherForecast 
                forecast={[
                  { day: "Mon", condition: "sunny", highTemp: 31, lowTemp: 23 },
                  { day: "Tue", condition: "cloudy", highTemp: 29, lowTemp: 21 },
                  { day: "Wed", condition: "rainy", highTemp: 26, lowTemp: 20 },
                ]}
              />
            </div>
          )}
        </section>

        <section className="space-y-6 pt-4">
          <div>
            <h2 className="text-2xl font-bold mb-2">Usability Testing & Feedback</h2>
            <p className="text-sm text-muted-foreground">
              Test the widgets above and share your feedback on ease of use, clarity, and visual appeal.
            </p>
          </div>
          
          <FeedbackForm onSubmit={handleFeedbackSubmit} />
          
          <div className="space-y-4">
            <h3 className="text-xl font-semibold">Submitted Feedback</h3>
            <FeedbackList feedbackItems={feedbackItems} />
          </div>
        </section>
      </div>
    </div>
  );
}
