import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star } from "lucide-react";

interface FeedbackItem {
  id: string;
  widgetName: string;
  rating: number;
  comment: string;
  testerName: string;
  createdAt: Date;
}

interface FeedbackListProps {
  feedbackItems: FeedbackItem[];
}

export default function FeedbackList({ feedbackItems }: FeedbackListProps) {
  const getWidgetBadgeColor = (widgetName: string) => {
    if (widgetName.includes("Spotify")) {
      return "bg-spotify-green text-spotify-green-foreground";
    }
    return "bg-ios-blue text-ios-blue-foreground";
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(date);
  };

  if (feedbackItems.length === 0) {
    return (
      <Card className="p-12 text-center" data-testid="card-no-feedback">
        <p className="text-muted-foreground">
          No feedback submitted yet. Be the first to share your thoughts!
        </p>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {feedbackItems.map((item) => (
        <Card key={item.id} className="p-6" data-testid={`feedback-item-${item.id}`}>
          <div className="flex items-start justify-between gap-4 mb-3">
            <Badge
              className={`${getWidgetBadgeColor(item.widgetName)} no-default-hover-elevate no-default-active-elevate`}
              data-testid="badge-widget-name"
            >
              {item.widgetName}
            </Badge>
            
            <div className="flex gap-0.5">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  className={`w-4 h-4 ${
                    star <= item.rating
                      ? "fill-yellow-400 text-yellow-400"
                      : "text-muted-foreground"
                  }`}
                  data-testid={`feedback-star-${star}`}
                />
              ))}
            </div>
          </div>
          
          <p className="text-foreground mb-3" data-testid="text-feedback-comment">
            {item.comment}
          </p>
          
          <div className="flex items-center justify-between text-sm text-muted-foreground">
            <span data-testid="text-tester-name">— {item.testerName}</span>
            <span data-testid="text-feedback-date">{formatDate(item.createdAt)}</span>
          </div>
        </Card>
      ))}
    </div>
  );
}
