import SpotifyNowPlaying from '../SpotifyNowPlaying';
import albumArt2 from '@assets/generated_images/Electronic_album_cover_art_ec1eaee8.png';

export default function SpotifyNowPlayingExample() {
  return (
    <SpotifyNowPlaying
      albumArt={albumArt2}
      songTitle="Neon Lights"
      artist="Synthwave Runner"
      isPlaying={true}
    />
  );
}
