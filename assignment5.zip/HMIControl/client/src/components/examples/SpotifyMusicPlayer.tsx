import SpotifyMusicPlayer from '../SpotifyMusicPlayer';
import albumArt1 from '@assets/generated_images/Album_cover_gradient_art_ce162ed5.png';

export default function SpotifyMusicPlayerExample() {
  return (
    <SpotifyMusicPlayer
      albumArt={albumArt1}
      songTitle="Midnight Vibes"
      artist="The Electric Dreams"
      audioUrl="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
    />
  );
}
