import FeedbackForm from '../FeedbackForm';

export default function FeedbackFormExample() {
  const handleSubmit = (feedback: any) => {
    console.log('Feedback submitted:', feedback);
  };

  return <FeedbackForm onSubmit={handleSubmit} />;
}
