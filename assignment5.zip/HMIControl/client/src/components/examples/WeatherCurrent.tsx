import WeatherCurrent from '../WeatherCurrent';

export default function WeatherCurrentExample() {
  return (
    <WeatherCurrent
      temperature={72}
      condition="sunny"
      location="San Francisco"
      highTemp={78}
      lowTemp={65}
    />
  );
}
