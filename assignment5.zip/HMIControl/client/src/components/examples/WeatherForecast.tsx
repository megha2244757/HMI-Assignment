import WeatherForecast from '../WeatherForecast';

export default function WeatherForecastExample() {
  const forecast = [
    { day: "Mon", condition: "sunny" as const, highTemp: 75, lowTemp: 62 },
    { day: "Tue", condition: "cloudy" as const, highTemp: 68, lowTemp: 58 },
    { day: "Wed", condition: "rainy" as const, highTemp: 64, lowTemp: 55 },
  ];

  return <WeatherForecast forecast={forecast} />;
}
