import FeedbackList from '../FeedbackList';

export default function FeedbackListExample() {
  const feedbackItems = [
    {
      id: "1",
      widgetName: "Spotify Music Player Controls",
      rating: 5,
      comment: "The controls are very intuitive and responsive. Love the green accent color that matches Spotify's branding. The play/pause animation is smooth and the progress bar is easy to understand.",
      testerName: "Sarah Johnson",
      createdAt: new Date(Date.now() - 1000 * 60 * 30),
    },
    {
      id: "2",
      widgetName: "Apple Weather Current",
      rating: 4,
      comment: "Clean iOS-style design with clear temperature display. The weather icon is simple and recognizable. Would be nice to have more detailed information like humidity or wind speed.",
      testerName: "Michael Chen",
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 2),
    },
    {
      id: "3",
      widgetName: "Spotify Now Playing Summary",
      rating: 5,
      comment: "Perfect at-a-glance widget! The album art is prominent and the NOW PLAYING label helps distinguish it from the full player. Very minimal and clean.",
      testerName: "Emily Rodriguez",
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 5),
    },
  ];

  return <FeedbackList feedbackItems={feedbackItems} />;
}
