import { useState, useEffect, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { SkipBack, Play, Pause, SkipForward } from "lucide-react";

interface SpotifyMusicPlayerProps {
  albumArt: string;
  songTitle: string;
  artist: string;
  audioUrl?: string;
  duration?: number;
}

export default function SpotifyMusicPlayer({
  albumArt,
  songTitle,
  artist,
  audioUrl,
  duration = 240,
}: SpotifyMusicPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [audioDuration, setAudioDuration] = useState(duration);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (audioUrl && !audioRef.current) {
      audioRef.current = new Audio(audioUrl);
      audioRef.current.addEventListener('loadedmetadata', () => {
        setAudioDuration(Math.floor(audioRef.current!.duration));
      });
      audioRef.current.addEventListener('timeupdate', () => {
        setCurrentTime(Math.floor(audioRef.current!.currentTime));
      });
      audioRef.current.addEventListener('ended', () => {
        setIsPlaying(false);
        setCurrentTime(0);
      });
    }

    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, [audioUrl]);

  useEffect(() => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.play();
      } else {
        audioRef.current.pause();
      }
    }
  }, [isPlaying]);

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
    console.log(isPlaying ? 'Paused' : 'Playing');
  };

  const handlePrevious = () => {
    console.log('Previous track');
    setCurrentTime(0);
    if (audioRef.current) {
      audioRef.current.currentTime = 0;
    }
  };

  const handleNext = () => {
    console.log('Next track');
    setIsPlaying(false);
    setCurrentTime(0);
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const progressPercentage = (currentTime / audioDuration) * 100;

  return (
    <Card className="p-6 shadow-lg" data-testid="card-spotify-player">
      <div className="flex gap-4">
        <img
          src={albumArt}
          alt={`${songTitle} album art`}
          className="w-20 h-20 rounded-lg object-cover flex-shrink-0"
          data-testid="img-album-art"
        />
        
        <div className="flex-1 min-w-0">
          <h3 className="font-medium text-lg truncate" data-testid="text-song-title">
            {songTitle}
          </h3>
          <p className="text-sm text-muted-foreground truncate" data-testid="text-artist">
            {artist}
          </p>
          
          <div className="mt-4 space-y-2">
            <div className="w-full bg-secondary h-1 rounded-full overflow-hidden">
              <div
                className="h-full bg-spotify-green transition-all duration-300"
                style={{ width: `${progressPercentage}%` }}
                data-testid="progress-bar"
              />
            </div>
            
            <div className="flex justify-between text-xs text-muted-foreground">
              <span data-testid="text-current-time">{formatTime(currentTime)}</span>
              <span data-testid="text-duration">{formatTime(audioDuration)}</span>
            </div>
          </div>

          <div className="flex items-center justify-center gap-2 mt-4">
            <Button
              size="icon"
              variant="ghost"
              onClick={handlePrevious}
              className="h-10 w-10"
              data-testid="button-previous"
            >
              <SkipBack className="h-5 w-5" />
            </Button>
            
            <Button
              size="icon"
              onClick={handlePlayPause}
              className="h-12 w-12 rounded-full bg-spotify-green hover:bg-spotify-green text-spotify-green-foreground"
              data-testid="button-play-pause"
            >
              {isPlaying ? (
                <Pause className="h-6 w-6" fill="currentColor" />
              ) : (
                <Play className="h-6 w-6" fill="currentColor" />
              )}
            </Button>
            
            <Button
              size="icon"
              variant="ghost"
              onClick={handleNext}
              className="h-10 w-10"
              data-testid="button-next"
            >
              <SkipForward className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
}
