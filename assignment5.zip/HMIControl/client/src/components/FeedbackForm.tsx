import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Star } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface FeedbackFormProps {
  onSubmit: (feedback: {
    widgetName: string;
    rating: number;
    comment: string;
    testerName: string;
  }) => void;
}

export default function FeedbackForm({ onSubmit }: FeedbackFormProps) {
  const [widgetName, setWidgetName] = useState("");
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState("");
  const [testerName, setTesterName] = useState("");
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!widgetName || rating === 0 || !comment.trim() || !testerName.trim()) {
      toast({
        title: "Missing Information",
        description: "Please fill in all fields before submitting.",
        variant: "destructive",
      });
      return;
    }

    onSubmit({
      widgetName,
      rating,
      comment: comment.trim(),
      testerName: testerName.trim(),
    });

    setWidgetName("");
    setRating(0);
    setComment("");
    setTesterName("");
    
    toast({
      title: "Feedback Submitted",
      description: "Thank you for your feedback!",
    });
  };

  return (
    <Card className="p-6" data-testid="card-feedback-form">
      <h2 className="text-2xl font-bold mb-6">Submit Usability Feedback</h2>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="tester-name">Your Name</Label>
          <Input
            id="tester-name"
            placeholder="Enter your name"
            value={testerName}
            onChange={(e) => setTesterName(e.target.value)}
            data-testid="input-tester-name"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="widget-select">Select Widget</Label>
          <Select value={widgetName} onValueChange={setWidgetName}>
            <SelectTrigger id="widget-select" data-testid="select-widget">
              <SelectValue placeholder="Choose a widget to review" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Spotify Music Player Controls">
                Spotify Music Player Controls
              </SelectItem>
              <SelectItem value="Spotify Now Playing Summary">
                Spotify Now Playing Summary
              </SelectItem>
              <SelectItem value="Apple Weather Current">
                Apple Weather Current Card
              </SelectItem>
              <SelectItem value="Apple Weather Forecast">
                Apple Weather Forecast Card
              </SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Rating</Label>
          <div className="flex gap-2">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                onClick={() => setRating(star)}
                onMouseEnter={() => setHoverRating(star)}
                onMouseLeave={() => setHoverRating(0)}
                className="focus:outline-none transition-transform hover:scale-110"
                data-testid={`star-${star}`}
              >
                <Star
                  className={`w-8 h-8 ${
                    star <= (hoverRating || rating)
                      ? "fill-yellow-400 text-yellow-400"
                      : "text-muted-foreground"
                  }`}
                />
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="comment">Feedback</Label>
          <Textarea
            id="comment"
            placeholder="Share your thoughts on ease of use, clarity, and visual appeal..."
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            className="min-h-32 resize-none"
            data-testid="textarea-comment"
          />
        </div>

        <Button
          type="submit"
          className="w-full"
          data-testid="button-submit-feedback"
        >
          Submit Feedback
        </Button>
      </form>
    </Card>
  );
}
