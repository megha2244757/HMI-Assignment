import { Card } from "@/components/ui/card";
import { Cloud, Sun, CloudRain, CloudSnow, CloudDrizzle } from "lucide-react";

interface WeatherCurrentProps {
  temperature: number;
  condition: string;
  location: string;
  highTemp: number;
  lowTemp: number;
}

export default function WeatherCurrent({
  temperature,
  condition,
  location,
  highTemp,
  lowTemp,
}: WeatherCurrentProps) {
  const getWeatherIcon = () => {
    const iconClass = "w-24 h-24 text-ios-blue";
    const conditionLower = condition.toLowerCase();
    
    if (conditionLower.includes('clear') || conditionLower.includes('sunny')) {
      return <Sun className={iconClass} />;
    } else if (conditionLower.includes('cloud')) {
      return <Cloud className={iconClass} />;
    } else if (conditionLower.includes('rain')) {
      return <CloudRain className={iconClass} />;
    } else if (conditionLower.includes('drizzle')) {
      return <CloudDrizzle className={iconClass} />;
    } else if (conditionLower.includes('snow')) {
      return <CloudSnow className={iconClass} />;
    }
    return <Sun className={iconClass} />;
  };

  const getConditionText = () => {
    return condition.charAt(0).toUpperCase() + condition.slice(1);
  };

  return (
    <Card className="p-8 shadow-sm border-border" data-testid="card-weather-current">
      <div className="text-center space-y-4">
        <p className="text-sm font-medium text-foreground" data-testid="text-location">
          {location}
        </p>
        
        <div className="flex justify-center" data-testid="icon-weather">
          {getWeatherIcon()}
        </div>
        
        <div>
          <div className="text-7xl font-bold tracking-tight" data-testid="text-temperature">
            {temperature}°
          </div>
          <p className="text-lg font-normal text-muted-foreground mt-2" data-testid="text-condition">
            {getConditionText()}
          </p>
        </div>
        
        <div className="flex justify-center gap-4 text-sm">
          <span className="text-muted-foreground" data-testid="text-high-temp">
            H: {highTemp}°
          </span>
          <span className="text-muted-foreground" data-testid="text-low-temp">
            L: {lowTemp}°
          </span>
        </div>
      </div>
    </Card>
  );
}
