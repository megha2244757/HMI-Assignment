import { Card } from "@/components/ui/card";
import { Cloud, Sun, CloudRain, CloudSnow, CloudDrizzle } from "lucide-react";

interface DayForecast {
  day: string;
  condition: string;
  highTemp: number;
  lowTemp: number;
}

interface WeatherForecastProps {
  forecast: DayForecast[];
}

export default function WeatherForecast({ forecast }: WeatherForecastProps) {
  const getWeatherIcon = (condition: string) => {
    const iconClass = "w-12 h-12 text-ios-blue";
    const conditionLower = condition.toLowerCase();
    
    if (conditionLower.includes('clear') || conditionLower.includes('sunny')) {
      return <Sun className={iconClass} />;
    } else if (conditionLower.includes('cloud')) {
      return <Cloud className={iconClass} />;
    } else if (conditionLower.includes('rain')) {
      return <CloudRain className={iconClass} />;
    } else if (conditionLower.includes('drizzle')) {
      return <CloudDrizzle className={iconClass} />;
    } else if (conditionLower.includes('snow')) {
      return <CloudSnow className={iconClass} />;
    }
    return <Sun className={iconClass} />;
  };

  return (
    <Card className="p-6 shadow-sm border-border" data-testid="card-weather-forecast">
      <h3 className="text-sm font-semibold mb-4 text-foreground">3-DAY FORECAST</h3>
      
      <div className="grid grid-cols-3 gap-4">
        {forecast.map((day, index) => (
          <div
            key={day.day}
            className={`text-center space-y-3 ${
              index < forecast.length - 1 ? 'border-r border-border pr-4' : ''
            }`}
            data-testid={`forecast-day-${index}`}
          >
            <p className="text-sm font-medium text-foreground" data-testid={`text-day-${index}`}>
              {day.day}
            </p>
            
            <div className="flex justify-center" data-testid={`icon-day-${index}`}>
              {getWeatherIcon(day.condition)}
            </div>
            
            <div className="space-y-1">
              <p className="text-base font-semibold" data-testid={`text-high-${index}`}>
                {day.highTemp}°
              </p>
              <p className="text-sm text-muted-foreground" data-testid={`text-low-${index}`}>
                {day.lowTemp}°
              </p>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
