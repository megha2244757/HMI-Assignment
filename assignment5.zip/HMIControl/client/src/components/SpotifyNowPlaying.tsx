import { Card } from "@/components/ui/card";
import { Music } from "lucide-react";

interface SpotifyNowPlayingProps {
  albumArt: string;
  songTitle: string;
  artist: string;
  isPlaying?: boolean;
}

export default function SpotifyNowPlaying({
  albumArt,
  songTitle,
  artist,
  isPlaying = true,
}: SpotifyNowPlayingProps) {
  return (
    <Card className="p-6 shadow-md hover-elevate" data-testid="card-spotify-nowplaying">
      <div className="flex items-center gap-4">
        <div className="relative">
          <img
            src={albumArt}
            alt={`${songTitle} album art`}
            className="w-24 h-24 rounded-lg object-cover"
            data-testid="img-nowplaying-album"
          />
          {isPlaying && (
            <div className="absolute bottom-2 right-2 bg-spotify-green rounded-full p-1.5">
              <Music className="h-3 w-3 text-white" />
            </div>
          )}
        </div>
        
        <div className="flex-1 min-w-0">
          <p className="text-xs text-muted-foreground mb-1">NOW PLAYING</p>
          <h3 className="font-semibold text-lg truncate" data-testid="text-nowplaying-title">
            {songTitle}
          </h3>
          <p className="text-sm text-muted-foreground truncate" data-testid="text-nowplaying-artist">
            {artist}
          </p>
        </div>
      </div>
    </Card>
  );
}
