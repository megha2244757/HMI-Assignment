# HMI Widget Assignment - Design Guidelines

## Design Approach

**Dual Design System Implementation**: This project requires two distinct visual languages operating side-by-side:
- **Spotify Widgets**: Android Material Design 3 principles with elevated surfaces, subtle shadows, and rounded corners
- **Apple Weather Widgets**: iOS flat design with minimal depth, precise typography, and clean lines

## Core Design Elements

### A. Typography

**Spotify Section (Material Design)**
- Primary: Inter or Roboto via Google Fonts
- Headings: font-semibold, text-xl to text-2xl
- Song titles: font-medium, text-lg
- Artist names: font-normal, text-sm with reduced opacity
- Controls: text-xs for labels

**Apple Weather Section (iOS Flat)**
- Primary: SF Pro Display alternative (Helvetica Neue or system-ui)
- Temperature: font-bold, text-6xl to text-7xl
- Location/condition: font-medium, text-base
- Forecast: font-regular, text-sm to text-base
- Consistent numerical weight hierarchy

**Feedback Section**
- Headers: font-bold, text-2xl
- Form labels: font-medium, text-sm
- Feedback text: font-normal, text-base
- Timestamps: font-light, text-xs

### B. Layout System

**Spacing Scale**: Use Tailwind units 2, 4, 6, 8, 12, 16 consistently
- Card padding: p-6 to p-8
- Section gaps: gap-8 to gap-12
- Widget spacing: space-y-6
- Button padding: px-6 py-3 to px-8 py-4

**Mobile Container Strategy**
- Max width: max-w-md (mobile device simulation)
- Center alignment: mx-auto
- Vertical flow: space-y-8 between major sections
- Safe area: px-4 outer padding

### C. Component Library

**Spotify Widgets**

*Music Player Controls Widget*
- Elevated card with rounded-2xl borders
- Album art: 80x80px rounded-lg thumbnail (left-aligned)
- Song info stack: Vertical layout with song title + artist
- Control buttons: Circular, filled, 48x48px with icons (Previous, Play/Pause, Next)
- Progress bar: Linear with rounded ends showing song duration
- Shadow: shadow-lg with Material elevation feel

*Now Playing Summary Widget*
- Compact horizontal card with rounded-xl
- Large album art: 120x120px rounded-lg (prominent placement)
- Text overlay or side-by-side layout
- Minimal controls, emphasize artwork and track info
- Subtle shadow: shadow-md

**Apple Weather Widgets**

*Current Weather Card*
- Flat surface with rounded-3xl corners
- Large temperature display: Center-aligned, massive font
- Weather icon: 96x96px simple line icons (sun, cloud, rain)
- Location text: Top-aligned, subtle weight
- Condition text: Below temperature, light weight
- Minimal shadow: shadow-sm or border instead
- Gradient background option representing weather condition

*Forecast Card*
- Horizontal 3-column grid layout (grid-cols-3)
- Each day: Centered vertical stack
- Day labels: Mon, Tue, Wed (abbreviated)
- Weather icons: 48x48px per day
- High/low temps: Stacked vertically with degree symbols
- Dividers: Subtle vertical lines between days
- No shadow, flat appearance

**Feedback Collection System**

*Feedback Form*
- Clean form card with rounded-xl
- Dropdown: Select widget (Spotify Controls, Spotify Now Playing, Weather Current, Weather Forecast)
- Text area: Multi-line for detailed feedback (min-h-32)
- Star rating: 1-5 stars visual selector
- Submit button: Full-width, prominent, rounded-lg
- Form validation: Inline error messages in red-500

*Feedback Display Section*
- Card-based layout for each feedback entry
- Widget badge: Colored pill showing which widget
- Rating: Visual star display
- Feedback text: Readable paragraph format
- Timestamp: Small, muted text
- User name/anonymous: Optional display
- Organized by widget type or chronologically

### D. Interactive Elements

**Buttons & Controls**
- Spotify play/pause: Toggle state with icon swap, smooth transition
- Weather forecast: Subtle hover scale (scale-105)
- Feedback submit: Loading state with spinner
- All buttons: Cursor-pointer, active states with slight scale-95

**State Management**
- Playing state: Visual indicator (pulsing icon or progress animation)
- Selected widget in form: Highlighted border
- Submitted feedback: Success toast/confirmation message
- Empty feedback state: Friendly placeholder text

### E. Visual Differentiation

**Section Headers**
- "Spotify Widgets" with Android green accent or Material purple
- "Apple Weather Widgets" with iOS blue accent
- Clear section dividers with horizontal rules or spacing
- Icons or logos to reinforce platform identity

**Platform Identity Markers**
- Spotify: Use Spotify green (#1DB954) for accents, buttons
- Weather: Use iOS blue (#007AFF) for interactive elements
- Maintain platform-specific iconography styles

## Images

**Album Artwork (Spotify Widgets)**
- Placeholder images: Use music-related abstract patterns or geometric designs
- Sizes: 80x80px for controls, 120x120px for now playing
- Treatment: Rounded corners (rounded-lg), subtle shadow

**Weather Icons**
- Line-based icons for iOS aesthetic: Sun, clouds, rain, snow variations
- Size: 96x96px for current, 48x48px for forecast
- Source: Use icon library (Heroicons weather subset or similar)
- Monochromatic or subtle color treatment

**No Hero Image**: This is a widget showcase interface, not a marketing page

## Accessibility & Polish

- Minimum touch target: 44x44px for all interactive elements
- Color contrast: WCAG AA compliance for all text
- Focus states: Visible ring-2 ring-offset-2 on keyboard focus
- ARIA labels: Proper screen reader support for controls
- Responsive scaling: Test at 375px, 414px, 768px widths

## Layout Hierarchy

1. **Page Header**: Project title "HMI Widget Assignment" with brief description
2. **Spotify Section**: Header + 2 widget cards in vertical stack
3. **Apple Weather Section**: Header + 2 widget cards in vertical stack
4. **Feedback Collection**: Form card with clear instructions
5. **Feedback Display**: Grid or list of submitted feedback entries
6. **Footer**: Optional credits or assignment info

**Vertical Rhythm**: Consistent py-8 to py-12 between major sections, creating clear visual separation while maintaining flow.